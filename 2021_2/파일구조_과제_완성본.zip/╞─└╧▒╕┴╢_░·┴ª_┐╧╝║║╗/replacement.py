import os

def replacement_sel(test_case,buffer,buffer_size):
  '''
  buffer[47, 2, 88, 88, 90]
  test_case[29, 42, 14, 19, 16]
  [2, 29, 42, 14, 19, 16, 47, 88, 88, 90, '\n', 14, 16]
  '''

  '''
  buffer[47, 2, 88, 88, 90]
  test_case[29, 42, 14, 19, 16]
  [2, 29, 42, 14, 19, 16, 47, 88, 88, 90, '\n', 14, 16]
  '''
  run1=list()
  frozen=list()


  for i in range(100):
    if len(test_case)==0:
      run1.extend(sorted(buffer))
      run1.append("\n")
      run1.extend(sorted(frozen))
      run1.append("\n")
      break

    elif len(test_case)!=0 and len(frozen)==buffer_size:
      run1.extend(sorted(buffer))
      run1.append("\n")
      buffer=frozen
      frozen=[]
      continue

    run1.append(min(buffer))
    if test_case[0]<run1[-1]:
      frozen.append(test_case[0])
      del buffer[buffer.index(min(buffer))]
    else:
      buffer[buffer.index(min(buffer))]=test_case[0]

    
    test_case=test_case[1:]
  
  return run1

def make_buffer(test_case):
    buff=list()
    buff_size=5
    test_case=list(map(int,test_case.split(" ")))
    buff.extend(test_case[:buff_size])
    test_case=test_case[buff_size:]
    return buff,test_case

def make_test_case(lines):
    test_case=list()
    for i in lines:
        if " "in i:
            test_case.append(i)
    return test_case

def main():
  f=open("C:\\Users\\View\\Desktop\\동아대학교\\2021_2학기\\파일처리론\\파일구조_과제_완성본\\replacement_input.txt","r")

  lines=list(map(lambda s: s.strip(), f.readlines()))
  test_cases=make_test_case(lines)
  # test_case="10 13 35 84 3 8 86 15 91 64 68 7 88 \n60 13 73 42 57 37 17 "

  with open("C:\\Users\\View\\Desktop\\동아대학교\\2021_2학기\\파일처리론\\파일구조_과제_완성본\\replacement_output.txt", "w") as file:
      for test_case in test_cases:
          buffer,test_case=make_buffer(test_case)
          run1=str(" ".join(list(map(str,replacement_sel(test_case, buffer,5)))))
          file.write(str(" ".join(list(map(str,[run1.count("\n"),"\n"])))))
          file.writelines(run1)
  f.close()
  print("replacement_input.txt의 내용을 replacement_selection을 이용하여 replacement_output.txt에 저장되었습니다.")
  return 0

main()

os.system("pause")