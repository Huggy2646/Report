#include <stdio.h>
#define MAX 30

int main(void)
{
    int i,j;
    int n=0;
    int m=0;
    
    int vMatrixA[MAX][MAX] = {0,};
    int vMatrixA[MAX][MAX] = {0,};
    int vResult[MAX][MAX] = {0,};

    printf("덧셈하려는 행렬의 크기를 입력하세요\n");
    printf("행렬의 행 크기 입력:");
    scanf("%d",&n);
    printf("행렬의 열 크기 입력:");
    scanf("%d",&m);
    
    printf("\n");
    printf("행렬의 값을 ")
}