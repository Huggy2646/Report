import numpy as np
arr1=np.array([[1,0],
                [0,-1]])
arr2=np.array([[1],
                [1]])
arr3=arr1*arr2
print(arr3)
