import os
def case_num(f_list):
    return f_list[0][0],f_list[1:]

def make_key_arr(f_list,keys_arr,case_num):
    keys=list()
    for i in range(int(case_num)):
        bucket=f_list[0][0]
        first_key_arr_num=f_list[0][1]
        key_arr_num=len(f_list[0])-1
        keys.append(bucket)
        keys.append(first_key_arr_num)
        for j in range(1,key_arr_num+1):
            keys.extend(f_list[j])
        keys_arr.append(keys)
        del f_list[:3]
        keys=list()
    return keys_arr

def h(n,k):
    return k%n

def h2(n,k):
    return (k%(n-2))+1
     
def h3(n,ads1,ads2, i):
    return (ads1+(i*ads2))%n

def Linear_find(adds,result,count):
    if count != len(result):
        if adds==len(result):
            return Linear_find(0,result,count+1)
        else:
            if result[adds]==0:
                return adds
            else:
                return Linear_find(adds+1,result,count+1)
    else:
        return False

def Linear_Probing(n,keys):
    result=[0]*n
    for k in keys:
        ads=h(n,k)
        if result[ads] == 0:
            result[ads]=k
        else:
            result[Linear_find(ads,result,0)]=k
    return result
    
def Two_Pass_Hash(n,f_k_arr_n,keys):
    result=[0]*n
    two_pass_arr=list()
    keys2=keys[:f_k_arr_n]
    for k in keys[:f_k_arr_n]:
        ads=h(n,k)
        if result[ads] == 0:
            result[ads]=k
        else:
            two_pass_arr.append(k)
            
    for k in two_pass_arr:
        ads=h(n,k)
        result[Linear_find(ads+1,result,0)]=k
    
    two_pass_arr=list()
        
    for k in keys[f_k_arr_n:]:
        ads=h(n,k)
        if result[ads] == 0:
            result[ads]=k
        else:
            two_pass_arr.append(k)
            
    for k in two_pass_arr:
        ads=h(n,k)
        result[Linear_find(ads+1,result,0)]=k
    
    return result

def Double_Hashing(n,keys):
    result=[0]*n
    i=1
    double_ads=0
    for k in keys:
        ads=h(n,k)
        ads2=h2(n,k)
        if result[ads]==0:
            result[ads]=k
        else:
            while True:
                if i!=3:
                    double_ads=h3(n,ads,ads2,i)
                    if result[double_ads]==0:
                        result[double_ads]=k
                        i=1
                        break
                    else:
                        i=i+1
                else:
                    result[Linear_find(double_ads,result,0)]=k
                    i=1
                    break

    return result

def main():
    keys_arr=list()
    f=open("C:\\Users\\View\\Desktop\\file_processing\\hash_input.txt","r")
    f_list=list()
    
    while True:
        line = f.readline()  
        f_list.append(line[0:len(line)-1])
        if not line:
            break
        
    for i in range(len(f_list)):
        f_list[i]=f_list[i].split() 
        
    for i in range(len(f_list)):
        f_list[i]=list(map(int,f_list[i]))
        
    cases_num,f_list=case_num(f_list)

    keys_arr=make_key_arr(f_list,keys_arr,cases_num)

    for i in range(len(keys_arr)):
        data1=(" ".join(map(str,Linear_Probing(keys_arr[i][0],keys_arr[i][2:]))))+"\n"
        data2=(" ".join(map(str,Two_Pass_Hash(keys_arr[i][0],keys_arr[i][1],keys_arr[i][2:]))))+"\n"
        data3=(" ".join(map(str,Double_Hashing(keys_arr[i][0],keys_arr[i][2:]))))+"\n"
        f = open("C:\\Users\\View\\Desktop\\file_processing\\hash_output.txt", 'a')
        f.write(data1)
        f.write(data2)
        f.write(data3)
        
    f.close()
    # print((" ".join(map(str,Linear_Probing(keys_arr[0][0],keys_arr[0][2:]))))+"\n")
    # print(" ".join(map(str,Two_Pass_Hash(keys_arr[7][0],keys_arr[7][1],keys_arr[7][2:])))+"\n")
    # print((" ".join(map(str,Double_Hashing(keys_arr[0][0],keys_arr[0][2:]))))+"\n")
    
main()
    
os.system("pause")