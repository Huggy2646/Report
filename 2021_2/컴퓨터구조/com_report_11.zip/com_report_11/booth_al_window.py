import tkinter as tk
from tkinter import *
from tkinter import messagebox
from tkinter import scrolledtext

def shift(a):
    return a[1:]+"0"
    
def sub(a,c,bit):
    c="1"+c
    result=bin(int(c,2)-int(a,2))
    return result[len(result)-(bit*2):]

def add(a,c,bit):
    c="1"+c
    result=bin(int(c,2)+int(a,2))
    return result[len(result)-(bit*2):]


win = Tk()
win.geometry("")
win.option_add("*Font","굴림 15")
win.title("Booth 알고리즘")



def main():
    def get_attribute():

        bit=int((ent0.get()))
        a=str((ent1.get()))
        b=str((ent2.get()))
        c="0"*(2*len(a))
        a_= ("0"*len(a))+a
        b_=b+"0"
        global result_arr
        result_arr=""
        result_arr=result_arr+("\n--------------------------------------------------------------------------------\n")
        result_arr=result_arr+("초기 피승수:\t"+a+"\n초기 승수:\t"+b+"\n초기 누적 부분곱:\t"+c+"\n"+"승수에 0을 붙여준다:"+b_+"\n")
        result_arr=result_arr+("\n"+a+"*"+b+"연산 과정")
        result_arr=result_arr+("\n--------------------------------------------------------------------------------\n")
        if len(a)!= bit or len(b)!= bit :
            messagebox.showinfo("주의!", "비트수가 다릅니다.")
            return win.mainloop()
        for i in range(len(b_)-1,0,-1):
            
            if b_[i-1]+b_[i] == "10":
                c=sub(a_,c,bit)
                result_arr=result_arr+(str(len(b_)-i)+"단계\n(10)\n"+" 피승수:\t\t"+a_+"\n\t\t-\n"+"누적 부분곱:\t\t"+c+"\n\t")
                result_arr=result_arr+("\n--------------------------------------------------------------------------------\n")
                a_ = shift(a_)    
                
            elif b_[i-1]+b_[i] == "11" or b_[i-1]+b_[i]=="00" :
                result_arr=result_arr+(str(len(b_)-i)+"단계\n"+"00 or 11이므로 시프트 연산만 진행\n"+"누적 부분곱:"+c+"\n\t")
                result_arr=result_arr+("\n--------------------------------------------------------------------------------\n")
                a_=shift(a_)
                
            else:
                c=add(a_,c,bit)
                result_arr=result_arr+(str(len(b_)-i)+"단계\n(01)\n"+" 피승수:\t\t"+a_+"\n\t\t+\n"+"누적 부분곱:\t\t"+c+"\n\t")
                result_arr=result_arr+("\n--------------------------------------------------------------------------------\n")
                a_=shift(a_)
        result_arr=result_arr+("\n결과 : "+ c)
            
        def createNewWindow():
            newWindow =tk.Toplevel(win)
            newWindow.title("Booth 알고리즘 결과")
            newWindow.resizable(width=False, height=False)
            log_text=scrolledtext.ScrolledText(newWindow)
            log_text.config(font=("굴림", 15))
            log_text.insert(END,result_arr)
            log_text.configure(state='disabled')
            log_text.pack()
        createNewWindow()
                
    label0 = Label(win)
    label0.configure(text="비트를 입력하세요(숫자만 입력 가능):")
    label0.pack()
    ent0=Entry(win)
    ent0.pack()

    label1 = Label(win)
    label1.configure(text="비트수에 맞게 2진수형태의 피승수를 입력하세요:")
    label1.pack()
    ent1 = Entry(win)
    ent1.pack()

    label2 = Label(win)
    label2.configure(text="비트수에 맞게 2진수형태의 승수를 입력하세요:")
    label2.pack()
    ent2 = Entry(win)
    ent2.pack()

        
    btn=Button(win)
    btn.config(text="계산")
    btn.config(command=get_attribute)

    btn.pack()
    
    
main()

win.mainloop()