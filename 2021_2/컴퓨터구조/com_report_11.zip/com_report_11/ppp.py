if 4:
    print("hello world")