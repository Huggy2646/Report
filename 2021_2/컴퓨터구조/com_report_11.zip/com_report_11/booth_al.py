# import os

def shift(a):
    return a[1:]+"0"
    
def sub(a,c,bit):
    c="1"+c
    result=bin(int(c,2)-int(a,2))
    return result[len(result)-(bit*2):]

def add(a,c,bit):
    c="1"+c
    result=bin(int(c,2)+int(a,2))
    return result[len(result)-(bit*2):]


def main():
    bit=int(input("비트를 입력하세요(숫자만 입력 가능):"))
    a=input("비트수에 맞게 2진수형태의 피승수를 입력하세요")
    b=input("비트수에 맞게 2진수형태의 승수를 입력하세요")
    
    if len(a)!= bit or len(b)!= bit :
        print("비트수가 다릅니다.")
        return main()
    
    c="0"*(2*len(a))
    a_= ("0"*len(a))+a
    b_=b+"0"

    for i in range(len(b_)-1,0,-1):
        
        print(len(b_)-i,"단계:")
        print("----------------------------")
        print(c)
        
        if b_[i-1]+b_[i] == "10":
            c=sub(a_,c,bit)
            print("-")
            print(a_)
            a_ = shift(a_)
            
            
        elif b_[i-1]+b_[i] == "11" or b_[i-1]+b_[i]=="00" :
            print("쉬프트 연산")
            print(a_)
            print("----------------------------")
            a_=shift(a_)
            
            
        else:
            c=add(a_,c,bit)
            print("+")
            print(a_)
            print("----------------------------")
            a_=shift(a_)
            
    print("결과:",c)
        

        
    try:
        input("프로그램이 끝났습니다. 계속하시려면 Enter를 눌려주세요 \n 종료하시려면 Ctrl+Z를 입력해주세요")
        main()
    except EOFError:
        pass

main()

